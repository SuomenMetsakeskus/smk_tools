
Luontotyökalut on tarkoitettu tukiaineistoksi metsätalouden toimenpiteiden suunnitteluun ja toteutukseen. Aineistot eivät poista maastosuunnittelun tarvetta, mutta niiden avulla on mahdollista suunnata suunnittelua vesiensuojelun ja monimuotoisuuden kannalta oleellisimmille kohteille.  

Työkalua voi käyttää QGIS-paikkatietosovelluksella.   

Tehokkaimmin voit hyödyntää työkaluja, jos voit ottaa niitä käyttöön omassa suunnittelujärjestelmässä.